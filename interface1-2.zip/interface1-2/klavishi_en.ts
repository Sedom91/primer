<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>Klavishi</name>
    <message>
        <location filename="klavishi.cpp" line="39"/>
        <location filename="klavishi.cpp" line="185"/>
        <source>ÐÐ°ÑÑÑÐ¾Ð¹ÐºÐ¸</source>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="klavishi.cpp" line="44"/>
        <location filename="klavishi.cpp" line="186"/>
        <source>Ð¡Ð¿Ð»Ð¾ÑÐ½Ð¾Ð¹ ÑÐµÐ¶Ð¸Ð¼</source>
        <translation type="unfinished">Multichannel</translation>
    </message>
    <message>
        <location filename="klavishi.cpp" line="48"/>
        <location filename="klavishi.cpp" line="187"/>
        <source>ÐÐ´Ð½Ð¾ÐºÐ°Ð½Ð°Ð»ÑÐ½ÑÐ¹</source>
        <translation type="unfinished">Singlechannel</translation>
    </message>
</context>
</TS>
