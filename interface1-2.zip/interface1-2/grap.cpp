#include <QtGui>
#include <QMenuBar>
#include"handle.h"
#include "klavishi.h"
#include "grap.h"
#include "qwt_plot.h"
Grap::Grap(QWidget*parent)
:QWidget(parent)
{


}


