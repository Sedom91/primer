<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>Handle</name>
    <message>
        <location filename="handle.cpp" line="10"/>
        <source>ÐÐ°ÑÑÑÐ¾Ð¹ÐºÐ¸</source>
        <translation type="unfinished">Settings</translation>
    </message>
</context>
</TS>
