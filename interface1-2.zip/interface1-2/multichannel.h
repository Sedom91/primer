#ifndef MULTICHANNEL_H
#define MULTICHANNEL_H
#include <QWidget>
#include <QFrame>
#include <QPalette>
#include <QPixmap>
#include <QMenu>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QMenuBar>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>

class Multichannel : public QWidget {
Q_OBJECT
public :
Multichannel(QWidget*parent=0);

};

#endif // MULTICHANNEL_H
